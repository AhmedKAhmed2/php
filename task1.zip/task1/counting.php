<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    // اظهار عدد الكلمات المتكررة
   $films = array("avatar","prestige","avatar","prestige");
   $keyword = "avatar";
$counting = substr($films,'avatar');
echo $counting;
 

    ?>
</body>
</html>