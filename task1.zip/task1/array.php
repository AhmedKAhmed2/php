<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   
    <?php
   


    // اظهار الرقم الاكبر عن طريق foreach
    
    $test = array(5,4,9,3,1,7,5,8,6);
    // $result = 0;
    // foreach ($test as  $num) {
    //     if($result < $num){
    //         $result = $num;
    //     }
    // };
    // echo $result;
    echo max ($test);
   
    ?>
</body>
</html>