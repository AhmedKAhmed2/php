<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
   $films = array("Fast","Predestination","Pursuit","Prestige",);
$keyword = "avatar";
    if (in_array($keyword,$films)) {
        echo "yes your found your films";
    }else
    {
        echo "Not Found Your Films";
        echo "<br>";
    };
    // البحث عن فيلم 
    $films = array("Fast","Predestination","Pursuit","Prestige","avatar");
    $keyword = "avatar";
    if (in_array($keyword,$films)) {
        echo "yes your found your films";
    }else
    {
        echo "Not Found Your Films";
    };

    ?>
</body>
</html>