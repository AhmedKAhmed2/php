<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    age
<input type="number" name="user_age" >
<input type="button" value="Submit">
    <?php
    $user_age = 18;
    if ($user_age === 18  ) {
        echo 'Go to Website';

    }else  {
         echo 'Your Under Age';
    }

?>
</body>
</html>