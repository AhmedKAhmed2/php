<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    // اظهار الحروف المتكررة عن طريق some
    $arr1=["a","b","c","d"];
    $arr2=["c","d","e","f"];
    for ($i=0; $i < count($arr1) ; $i++) { 
        if ($arr1[$i] == $arr2[$i]) {
          echo $arr1[$i].':'.'is same:'.$arr2[$i].'<br>'; 
        }else
        {
           echo $arr1[$i].':'.'is same value as:'.$arr2[$i].'<br>'; 
        }
    }

    
    ?>
</body>
</html>